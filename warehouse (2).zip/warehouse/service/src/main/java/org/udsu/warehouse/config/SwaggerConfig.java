package org.udsu.warehouse.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

}
